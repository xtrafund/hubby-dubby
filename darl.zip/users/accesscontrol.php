<?php // accesscontrol.php
include_once '../common.php';
include '../db.class.mysqli.php';
include("../ref.php");

session_start();

$uid = isset($_POST['uid']) ? $_POST['uid'] : $_SESSION['uid'];
$pwd = isset($_POST['pwd']) ? $_POST['pwd'] : $_SESSION['pwd'];
if(!isset($uid)) {
  ?>
  
 <!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="shortcut icon" href="../images/favicon.png" type="image/x-icon">
  <meta name="description" content="">
  <title>LOGIN</title>
  
  <link rel="stylesheet" href="../assets/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="../assets/mobirise/css/style.css">
  <link rel="stylesheet" href="../assets/mobirise/css/mbr-additional.css" type="text/css">
    <style>
  	body {
  		overflow-y: hidden;
  		margin: 0;
  	}
  </style>
  
  
</head>
  <body>

<nav class="navbar navbar-default navbar-fixed-top">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <div id="logo">
				<a href="index.php"><img src="../assets/images/logo.jpg" alt="" height="20%" width="50%" /></a>		
			</div>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav navbar-right">
        <li class="selected"><a href="../index.php">HOME</a></li>
        <li><a href="../about.php">ABOUT US</a></li>
        <li><a href="../services.php">SERVICES</a></li>
        <li><a href="../how_it_works.php">HOW IT WORKS</a></li>
        <li><a href="../contact.php">CONTACT</a></li>
        <li><a href="dashboard.php">LOGIN</a></li>
     </ul>
    </div>
  </div>
</nav>
<section class="mbr-section mbr-section--relative mbr-section--fixed-size mbr-after-navbar" id="form1-29" style="background-color: rgb(239, 239, 239);">

    
    <div class="mbr-section__container mbr-section__container--std-padding container" style="padding-top: 93px; padding-bottom: 93px;">
        <div class="row">
            <div class="col-sm-12">
                <div class="row">
                
                
                    <div class="col-sm-8 col-sm-offset-2">
                        <div class="mbr-header mbr-header--center mbr-header--std-padding">
                            <h2 class="mbr-header__text">LOGIN</h2>
                        </div>
                        
                        <div class="row">
                        
                        <div class="col-md-3"></div>
                        <form method="post" action="<?=$_SERVER['PHP_SELF']?>">
                            
                            <div class="col-md-5">
                            <div class="form-group">
                                <input type="text" class="form-control" name="uid" required="" placeholder="Username*">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" name="pwd" placeholder="Password*">
                            </div>
                            <div class="mbr-buttons mbr-buttons--left">
                            <p style="color: #333;">Not Registered yet? <span><a href ="../signup.php" style="font-size: 19px"> Sign up</a></span></p></div>
                             <div class="mbr-buttons mbr-buttons--right">
                             <input type="submit" class="btn btn-primary btn-sm" value="LOGIN" style="padding:6px;"/></div>	
                               </div>
                        </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>



  <script src="../assets/web/assets/jquery/jquery.min.js"></script>
  <script src="../assets/bootstrap/js/bootstrap.min.js"></script>
  <script src="../assets/smooth-scroll/SmoothScroll.js"></script>
  <!--[if lte IE 9]>
    <script src="assets/jquery-placeholder/jquery.placeholder.min.js"></script>
  <![endif]-->
  
  
</body>
</html>

  <?php
  exit;
}

$_SESSION['uid'] = $uid;
$_SESSION['pwd'] = $pwd;

$sql = "SELECT * FROM users WHERE
        userid = '$uid' AND userpsw = '$pwd'";
    $result = $mysqli->query($sql);

        
if (!$result) {
  error('A database error occurred while checking your '.
        'login details.\\nIf this error persists, please '.
        'contact you@example.com.');
}


if($result->num_rows < 1) {
	session_destroy();
  error('Your user ID or password is incorrect, or you are not '.
        'a registered user on this site. Try logging in again.');
  ?>
 
 <?php
  exit;
}


if($result->num_rows) {
  while($row=$result->fetch_assoc()) {
    extract($row);
    $access_level = $row['status'];
    }
  }

  if($access_level == 0) {
    session_destroy();
    error("Sorry you are blocked from this site, Please contact Admin");
    exit;
    }

$username = mysql_result($result,0,'firstname');
?>
