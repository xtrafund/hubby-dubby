       <?php
include "../db.class.mysqli.php";

            $action = isset($_GET['action']) ? $_GET['action'] : "";
            $uid = isset($_GET['uid']) ? $_GET['uid'] : "";

            if($action == "activate") {

// Get to know the number of payments that the user has received
              $sql="SELECT * FROM users WHERE userid = '$uid'";
    $result=$mysqli->query($sql);
if($result->num_rows > 0) {
  
  //Gets the result and increments it by 1
  while($row=$result->fetch_assoc()) {
    $no_of_received = $row['received_payment'];
    $increase = $no_of_received + 1;
    }
    }
               // Increase the payment_counter of column of the user that just confirmed a fellow user
              $sql = "UPDATE users SET received_payment = '$increase' WHERE userid = '$uid'";
              $result = $mysqli->query($sql);

               // Clear the receiver's message column and tell them the no of payments that they have received
               $sql = "UPDATE users SET message = 'You have received $increase payment' WHERE userid = '$uid'";
              $result = $mysqli->query($sql);

                //Tell the newly confirmed user that they have been confirmed
               $sql = "UPDATE users SET message = 'You have been confirmed' WHERE identification_id = ".$mysqli->real_escape_string($_GET['identification_id'])."";
              $result = $mysqli->query($sql);

                //Clear the merge_to_pay column of the newly confirmed user
               $sql = "UPDATE users SET merge_to_pay = '' WHERE identification_id = ".$mysqli->real_escape_string($_GET['identification_id'])."";
              $result = $mysqli->query($sql);

               // The merge_to_receive column of the receiving user
               $sql = "UPDATE users SET merge_to_receive = '' WHERE userid = '$uid'";
              $result = $mysqli->query($sql);

               // Update the confirmation column of the new user Most Important task
              $sql = "UPDATE users SET confirmed = 1 WHERE identification_id = ".$mysqli->real_escape_string($_GET['identification_id'])."";
              if($mysqli->query($sql)) {
                echo "<script>alert('User has been confirmed successfully');</script>";
                ?>
                <!DOCTYE html>
                <html>
                <body>
                <div style="text-align: center;margin-top:70px; background: #ccc; color:#000; height: 200px;padding-top: 50px;"> 
                You have done great!!! <br/><br/> 
                User successfully confirmed .
                Click <a href = "dashboard.php"> here</a> to go back to Dashborad.
                </div>
                </body>
                </html>
                <?
              } else {
                echo "<script>alert('Error in operation');</script>";
              }
            }

              ?>