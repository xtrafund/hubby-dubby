 <?php
		    echo "<script>history.back()</script>";

		    			    	?>
<!--
		    			    	/*
              include "../db.class.mysqli.php";
              include "../common.php";
              
              
              
              $action = isset($_GET['action']) ? $_GET['action'] : "";
              
   
              if($action=='personal') {
  if ($_POST['newid']=='' && $_POST['newname']==''
      && $_POST['newemail']=='') {
        error('One or more required fields were left blank.\\n'.
              'Please fill them in and try again.');
    }
              	
			$sql = "UPDATE users SET message = 'You have been merged to pay $rwallet to $rfname $rlname,\n Phone number is: $rp_num \n Account Details /n Acc Name:$ra_name \n Acc No:$ra_no \n Bank Name:$rb_name' WHERE activation_code = '$code'";
		    	$result=$mysqli->query($sql);

		    }-->
